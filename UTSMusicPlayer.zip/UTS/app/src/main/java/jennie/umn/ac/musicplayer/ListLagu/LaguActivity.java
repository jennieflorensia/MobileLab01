package jennie.umn.ac.musicplayer.ListLagu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;

import java.util.ArrayList;
import java.util.zip.Inflater;

import jennie.umn.ac.musicplayer.R;

public class LaguActivity extends AppCompatActivity {

    static ArrayList<LaguSource> laguSource;
    RecyclerView rvDaftarLagu;
    DaftarLaguAdapter daftarLaguAdapter;
    public static ArrayList<LaguSource> getAllAudio(Context context)
    {
        ArrayList<LaguSource> listLaguTemp = new ArrayList<>();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA //for path
        };

        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);

        if(cursor != null)
        {
            while(cursor.moveToNext())
            {
                String title = cursor.getString(0);
                String artist = cursor.getString(1);
                String album = cursor.getString(2);
                String duration = cursor.getString(3);
                String path = cursor.getString(4);

                LaguSource lagusource = new LaguSource(path, title, artist, duration, album);
                Log.e("Path : " + path, " Album : " + album);
                listLaguTemp.add(lagusource);
            }
            cursor.close();
        }
        return listLaguTemp;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lagu);
        dialogWelcome();
        laguSource = getAllAudio(this);
        rvDaftarLagu = (RecyclerView) findViewById(R.id.recyclerView);
        daftarLaguAdapter = new DaftarLaguAdapter(this, laguSource);
        rvDaftarLagu.setAdapter(daftarLaguAdapter);
        rvDaftarLagu.setLayoutManager(new LinearLayoutManager(this));
    }

    private void dialogWelcome()
    {
        DialogWelcome dialogWelcome = new DialogWelcome();
        dialogWelcome.show(getSupportFragmentManager(), "welcome message");
    }
}